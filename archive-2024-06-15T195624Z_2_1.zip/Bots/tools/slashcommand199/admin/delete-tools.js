const { SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/tools.json")

module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('remove-tools')
    .setDescription('ازالة ادات')
  .addStringOption(text => text
    .setName(`tools-name`)
    .setDescription(`اسم ادات`)
    .setRequired(true)),
  
  
  async execute(interaction) {


    const toolsName = interaction.options.getString('tools-name');

    const toolss = await db.get(`toolss_${interaction.guild.id}`);

    const toolsToRemove = codes.find(tools => tools.toolsName === toolsName);

    if (!toolsToRemove) return interaction.reply({ content: `**ادات غير موجود.**`, ephemeral: true });

    db.set(`toolss_${interaction.guild.id}`, toolss.filter(tools => tools.toolsName !== toolsName));

    interaction.reply({ content: `**تم إزالة ادات بنجاح**` });
    
  }
}

  const { Client, Collection,AuditLogEvent, discord,GatewayIntentBits, Partials , EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message ,Attachment} = require("discord.js");

  const { Database } = require("st.db")
  const allDB = new Database("/Json-db/Bots/allDB.json")
  const tokens = new Database("/tokens/tokens")
  const tier1subscriptions = new Database("/database/makers/tier1/subscriptions")
  const Captchas = [
     {
        Captchas: `https://cdn.discordapp.com/attachments/1204187638312210543/1204926002699182280/72958.webp?ex=65d681c9&is=65c40cc9&hm=57b8d46993aa2887de00aed0454a50f1c26d0e8685b72d1cdb1be1ee3c98b3fc&`,
        Number: 72958
    },
    {
        Captchas: `https://cdn.discordapp.com/attachments/1204187638312210543/1204926016909344818/88275.webp?ex=65d681cc&is=65c40ccc&hm=05eff69069d015563977e36bb28dbf11e830aa5458e1c7afcb8122a54f21cad3&`,
        Number: 88275
    },
    {
        Captchas: `https://cdn.discordapp.com/attachments/1204187638312210543/1204926034206793769/89725.webp?ex=65d681d0&is=65c40cd0&hm=926a0e27b45ab8d8e659e3134c70e322bbe10aa3ef04b1880ab2521e18bd1320&`,
        Number: 89725
    },
    {
        Captchas: `https://cdn.discordapp.com/attachments/1204187638312210543/1204926048706502696/99910.webp?ex=65d681d4&is=65c40cd4&hm=d068caa101daaee3adc0ba6a330798a28a18ee33a956c62357f1c99f2d730a09&`,
        Number: 99910
    },
    {
        Captchas: `https://cdn.discordapp.com/attachments/1204187638312210543/1204926069442875472/88039.webp?ex=65d681d9&is=65c40cd9&hm=4cf8a36181df072ab47fac6f91663a5e6008e5dafeca3e5d42619e202ad36a58&`,
        Number: 88039
    }
]
  
  let all = tokens.get('all')
  if(!all) return;
  
  const path = require('path');
  const { readdirSync } = require("fs");
  let theowner;
  all.forEach(async(data) => {
    const { REST } = require('@discordjs/rest');
    const { Routes } = require('discord-api-types/v10');
    const { prefix , token , clientId , owner } = data;
    theowner = owner
    const client100 = new Client({intents: [GatewayIntentBits.Guilds,GatewayIntentBits.GuildMessageReactions, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildMessageTyping, GatewayIntentBits.MessageContent]},{intents: 32767, shards: "auto", partials: [Partials.Message, Partials.Channel, Partials.GuildMember,]});
    client100.commands = new Collection();
    require(`./handlers/events`)(client100);
    client100.events = new Collection();
    require(`../../events/requireBots/all-commands`)(client100);
    const rest = new REST({ version: '10' }).setToken(token);
    client100.on("ready" , async() => {
  
        try {
          await rest.put(
            Routes.applicationCommands(client100.user.id),
            { body: allSlashCommands },
            );
            
          } catch (error) {
            console.error(error)
          }
  
      });
      require(`../all/handlers/events`)(client100)
      require(`../all/handlers/applyCreate`)(client100)
      require(`../all/handlers/applyResult`)(client100)
      require(`../all/handlers/applySubmit`)(client100)
      require(`./handlers/ticketClaim`)(client100);
      require(`./handlers/ticketCreate`)(client100);
      require(`./handlers/ticketDelete`)(client100);
      require(`./handlers/ticketSubmitCreate`)(client100);
      require(`./handlers/ticketUnclaim`)(client100);
      require(`./handlers/suggest`)(client100);
      require(`./handlers/orders-events`)(client100);

      const folderPath2 = path.join(__dirname, 'commands100');

      for(let foldeer of readdirSync(folderPath2).filter((folder) => !folder.includes("."))) {
        for(let fiee of(readdirSync(`${folderPath2}/${foldeer}`).filter((fi) => fi.endsWith(".js")))) {
          const commander = require(`${folderPath2}/${foldeer}/${fiee}`)
        }
      }
      
      require(`../../events/requireBots/all-commands`)(client100)
      require("./handlers/events")(client100)
      
        for (let file of readdirSync('./events/').filter(f => f.endsWith('.js'))) {
          const event = require(`./events/${file}`);
        if (event.once) {
          client100.once(event.name, (...args) => event.execute(...args));
        } else {
          client100.on(event.name, (...args) => event.execute(...args));
        }
        }




    const folderPath = path.join(__dirname, 'slashcommand100');
    client100.allSlashCommands = new Collection();
    const allSlashCommands = [];
    const ascii = require("ascii-table");
    const table = new ascii("all commands").setJustify();
    for (let folder of readdirSync(folderPath).filter(
      (folder) => !folder.includes(".")
      )) {
        for (let file of readdirSync(`${folderPath}/` + folder).filter((f) =>
        f.endsWith(".js")
        )) {
          let command = require(`${folderPath}/${folder}/${file}`);
          if (command) {
            allSlashCommands.push(command.data.toJSON());
            client100.allSlashCommands.set(command.data.name, command);
            if (command.data.name) {
              table.addRow(`/${command.data.name}`, "🟢 Working");
            } else {
              table.addRow(`/${command.data.name}`, "🔴 Not Working");
            }
          }
    }
  }
  client100.on('messageCreate' , async(message) => {
    if(message.author.bot) return;
    let roomid = allDB.get(`tax_room_${message.guild.id}`)
    if(roomid) {
      if(message.channel.id == roomid) {
        if(message.author.bot) return;
        let number = message.content
      if(number.endsWith("k")) number = number.replace(/k/gi, "") * 1000;
  else if(number.endsWith("K")) number = number.replace(/K/gi, "") * 1000;
      else if(number.endsWith("m")) number = number.replace(/m/gi, "") * 1000000;
    else if(number.endsWith("M")) number = number.replace(/M/gi, "") * 1000000;
        let number2 = parseInt(number)
      let tax = Math.floor(number2 * (20) / (19) + 1) // المبلغ مع الضريبة
      let tax2 = Math.floor(tax - number2) // الضريبة
      let tax3 = Math.floor(tax * (20) / (19) + 1) // المبلغ مع ضريبة الوسيط
      let tax4 = Math.floor(tax3 - tax) // ضريبة الوسيط
  let embed1 = new EmbedBuilder()
  .setFooter({text:message.author.username , iconURL:message.author.displayAvatarURL({dynamic:true})})
      .setAuthor({name:message.guild.name , iconURL:message.guild.iconURL({dynamic:true})})
      .setTimestamp(Date.now())
      .setColor('#000000')
      .addFields([
          {
              name:`**المبلغ**` , value:`**\`${number2}\`**` , inline:true
          },
          {
              name:`**المبلغ مع الضريبة**` , value:`**\`${tax}\`**` , inline:true
          },
          {
              name:`**المبلغ مع ضريبة الوسيط**` , value:`**\`${tax3}\`**` , inline:false
          },
          {
              name:`**الضريبة**` , value:`**\`${tax2}\`**` , inline:true
          },
          {
              name:`**ضريبة الوسيط**` , value:`**\`${tax4}\`**` , inline:true
          }
      ])
      return message.reply({embeds:[embed1]})
      }
    }
  })

  client100.on("messageCreate" , async(message) => {
    if(message.author.bot) return;
    try {
      if(message.content == "-" || message.content == "خط") {
        const line = addDB.get(`line_${message.guild.id}`)
        if(line) {
          await message.delete()
          return message.channel.send({content:`${line}`});
        }
      }
    } catch (error) {
      return;
    }
   
  })
  
  client100.on("messageCreate" , async(message) => {
    if(message.author.bot) return;
    const autoChannels = allDB.get(`line_channels_${message.guild.id}`)
      if(autoChannels) {
        if(autoChannels.length > 0) {
          if(autoChannels.includes(message.channel.id)) {
            const line = allDB.get(`line_${message.guild.id}`)
        if(line) {
          return message.channel.send({content:`${line}`});
          }
        }
        }
      }
  })

      client100.on("messageCreate" , async(message) => {
        if(message.author.bot) return;
        const line = allDB.get(`line_${message.guild.id}`)
        const chan = allDB.get(`suggestions_room_${message.guild.id}`)
        if(line && chan) {
         if(chan != message.channel.id) return;
          const embed = new EmbedBuilder()
          .setTimestamp()
          .setTitle(`**${message.content}**`)
          .setAuthor({name:message.author.username , iconURL:message.author.displayAvatarURL({dynamic:true})})
          .setFooter({text:message.guild.name , iconURL:message.guild.iconURL({dynamic:true})})
          const button1 = new ButtonBuilder()
          .setCustomId(`ok_button`)
          .setLabel(`0`)
          .setEmoji("✅")
          .setStyle(ButtonStyle.Success)
          const button2 = new ButtonBuilder()
          .setCustomId(`no_button`)
          .setLabel(`0`)
          .setEmoji("❌")
          .setStyle(ButtonStyle.Danger)
          const row = new ActionRowBuilder().addComponents(button1 , button2)
          let send = await message.channel.send({embeds:[embed] , components:[row]}).catch(() => {return interaction.reply({content:`**الرجاء التأكد من صلاحياتي**`})})
          await message.channel.send({content:`${line}`})
          await allDB.set(`${send.id}_ok` , 0)
          await allDB.set(`${send.id}_no` , 0)
          return message.delete()
      
        }
      })

      client100.on('messageCreate', async (message) => {
        const status = 'on'
        if (status === "on") {
          if (message.content.includes('type these numbers to confirm')) return;
    
          if (message.author.id === '282859044593598464') {
            try {
              if (message.content.includes('You are eligible to receive your daily for the bot!')) {
                const buttonComponent = message.components.find(component => component.type === 'ACTION_ROW')?.components.find(component => component.type === 'BUTTON');
                await message.delete();
                const lastMessage = message.channel.messages.cache.last();
                const row = new MessageActionRow()
                  .addComponents(buttonComponent);
                return lastMessage.reply({
                  content: `${message.content}`,
                  components: [row]
                }).catch(async() => {
                  return message.channel.send({
                    content: `${message.content}`,
                  components: [row]
                  })
                })
              }
              if (message.content.includes('You can get up to 2600 credits if you vote for ProBot!')) {
                const buttonComponent = message.components.find(component => component.type === 'ACTION_ROW')?.components.find(component => component.type === 'BUTTON');
                await message.delete();
                const lastMessage = message.channel.messages.cache.last();
                const row = new MessageActionRow()
                  .addComponents(buttonComponent);
                return lastMessage.reply({
                  content: `${message.content}`,
                  components: [row]
                }).catch(async() => {
                  return message.channel.send({
                    content: `${message.content}`,
                  components: [row]
                  })
                })
              }
              if (message.author.bot && message.embeds.length > 0) {
                await message.delete();
                const lastMessage = message.channel.messages.cache.last();
                const embed = new EmbedBuilder(message.embeds[0]);
                return lastMessage.reply({ embeds: [embed] }).catch(async() => {
                  return message.channel.send({
                    embeds:[embed]
                  })
                })
              }
    
              if (message.content && message.attachments.size > 0) {
                const attach = message.attachments.first();
                await message.delete();
                const lastMessage = message.channel.messages.cache.last();
                return lastMessage.reply({ content: `${message}`, files: [{ name: `'pic.png'`, attachment: attach.url }] }).catch(async() => {
                  message.channel.send({content: `${message}`, files: [{ name: `'pic.png'`, attachment: attach.url }]})
                })
              }
    
              if (message.attachments.size > 0) {
                const attach = message.attachments.first();
                await message.delete();
                const lastMessage = message.channel.messages.cache.last();
                return lastMessage.reply({ files: [{ name: 'pic.png', attachment: attach.url }] }).catch(async() => {
                  message.channel.send({ files: [{ name: 'pic.png', attachment: attach.url }] })
                })
              }
    
              await message.delete().catch(err => { })
              const lastMessage = message.channel.messages.cache.last();
              let sentMessage;
                sentMessage = await lastMessage.reply({ content: `${message}` }).catch(async() => {
                 sentMessage = message.channel.send({content:`${message}`})
              })
    
             
            } catch {
            }
          }
        } else {
          return;
        }
      });
      client100.on('messageCreate', async (message) => {
        const status = 'on'
        if (status === "on") {
          if (message.content.includes('type these numbers to confirm')) return;
    
          if (message.author.id === '282859044593598464') {
            try {
              if (message.content.includes('You are eligible to receive your daily for the bot!')) {
                const buttonComponent = message.components.find(component => component.type === 'ACTION_ROW')?.components.find(component => component.type === 'BUTTON');
                await message.delete();
                const lastMessage = message.channel.messages.cache.last();
                const row = new MessageActionRow()
                  .addComponents(buttonComponent);
                return lastMessage.reply({
                  content: `${message.content}`,
                  components: [row]
                }).catch(async() => {
                  return message.channel.send({
                    content: `${message.content}`,
                  components: [row]
                  })
                })
              }
              if (message.content.includes('You can get up to 2600 credits if you vote for ProBot!')) {
                const buttonComponent = message.components.find(component => component.type === 'ACTION_ROW')?.components.find(component => component.type === 'BUTTON');
                await message.delete();
                const lastMessage = message.channel.messages.cache.last();
                const row = new MessageActionRow()
                  .addComponents(buttonComponent);
                return lastMessage.reply({
                  content: `${message.content}`,
                  components: [row]
                }).catch(async() => {
                  return message.channel.send({
                    content: `${message.content}`,
                  components: [row]
                  })
                })
              }
              if (message.author.bot && message.embeds.length > 0) {
                await message.delete();
                const lastMessage = message.channel.messages.cache.last();
                const embed = new EmbedBuilder(message.embeds[0]);
                return lastMessage.reply({ embeds: [embed] }).catch(async() => {
                  return message.channel.send({
                    embeds:[embed]
                  })
                })
              }
    
              if (message.content && message.attachments.size > 0) {
                const attach = message.attachments.first();
                await message.delete();
                const lastMessage = message.channel.messages.cache.last();
                return lastMessage.reply({ content: `${message}`, files: [{ name: `'pic.png'`, attachment: attach.url }] }).catch(async() => {
                  message.channel.send({content: `${message}`, files: [{ name: `'pic.png'`, attachment: attach.url }]})
                })
              }
              await message.delete().catch(err => { })
              const lastMessage = message.channel.messages.cache.last();
              let sentMessage;
                sentMessage = await lastMessage.reply({ content: `${message}` }).catch(async() => {
                 sentMessage = message.channel.send({content:`${message}`})
              })
    
             
            } catch {
            }
          }
        } else {
          return;
        }
      });
      client100.on("guildMemberAdd" , async(member) => {
        const theeGuild = member.guild
        let rooms = allDB.get(`rooms_${theeGuild.id}`)
        const message = allDB.get(`message_${theeGuild.id}`)
        if(!rooms) return;
        if(rooms.length <= 0) return;
        if(!message) return;
        await rooms.forEach(async(room) => {
          const theRoom = await theeGuild.channels.cache.find(ch => ch.id == room)
          if(!theRoom) return;
          await theRoom.send({content:`${member} , ${message}`}).then(async(msg) => {
            setTimeout(() => {
              msg.delete();
            }, 1500);
          })

      client100.on("messageCreate" , async(message) => {
          if(message.author.id != client100.user.id) return;
           if (message.content.includes('Cool down')) {
                setTimeout(() => {
                  message.delete();
                }, 3000);
              }
              if (message.content.includes(`Deleting messages`)) {
                setTimeout(() => {
                  message.delete();
                }, 3000);
              }
    })
    
      client100.on("messageCreate" , async(message) => {
          if(message.author.id != client100.user.id) return;
           if (message.content.includes('Cool down')) {
                setTimeout(() => {
                  message.delete();
                }, 3000);
              }
              if (message.content.includes(`Deleting messages`)) {
                setTimeout(() => {
                  message.delete();
                }, 3000);
              }
    })
    client100.on('messageDelete' , async(message) => {
      if(!message) return;
      if(!message.author) return;
      if(message.author.bot) return;
    if (!allDB.has(`log_messagedelete_${message.guild.id}`)) return;
    let deletelog1 = allDB.get(`log_messagedelete_${message.guild.id}`)
      let deletelog2 = message.guild.channels.cache.get(deletelog1)
      const fetchedLogs = await message.guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.MessageDelete
      });
      const deletionLog = fetchedLogs.entries.first();
      const { executor, target } = deletionLog;
    let deleteembed = new EmbedBuilder()
    .setTitle(`**تم حذف رسالة**`)
        .addFields(
          {
            name: `**صاحب الرسالة : **`, value: `**\`\`\`${message.author.tag} - (${message.author.id})\`\`\`**`, inline: false
          },
          {
            name: `**حاذف الرسالة : **`, value: `**\`\`\`${executor.username} - (${executor.id})\`\`\`**`, inline: false
          },
          {
            name: `**محتوى الرسالة : **`, value: `**\`\`\`${message.content}\`\`\`**`, inline: false
          },
          {
            name: `**الروم الذي تم الحذف فيه : **`, value: `${message.channel}`, inline: false
          }
        )
        .setTimestamp();
      await deletelog2.send({ embeds: [deleteembed] })
  })
client100.on('messageUpdate' , async(oldMessage, newMessage) => {
    if(!oldMessage.author) return;
    if(oldMessage.author.bot) return;
  if (!allDB.has(`log_messageupdate_${oldMessage.guild.id}`)) return;
  const fetchedLogs = await oldMessage.guild.fetchAuditLogs({
    limit: 1,
    type: AuditLogEvent.MessageUpdate
  });
  let updateLog1 = allDB.get(`log_messageupdate_${oldMessage.guild.id}`);
      let updateLog2 = oldMessage.guild.channels.cache.get(updateLog1); 
  const updateLog = fetchedLogs.entries.first();
  const { executor } = updateLog;
  let updateEmbed = new EmbedBuilder()
  .setTitle(`**تم تعديل رسالة**`)
  .addFields(
    {
      name: "**صاحب الرسالة:**",
      value: `**\`\`\`${oldMessage.author.tag} (${oldMessage.author.id})\`\`\`**`,
      inline: false
    },
    {
      name: "**المحتوى القديم:**",
      value: `**\`\`\`${oldMessage.content}\`\`\`**`,
      inline: false
    },
    {
      name: "**المحتوى الجديد:**",
      value: `**\`\`\`${newMessage.content}\`\`\`**`,
      inline: false
    },
    {
      name: "**الروم الذي تم التحديث فيه:**",
      value: `${oldMessage.channel}`,
      inline: false
    }
  )
  .setTimestamp()
  await updateLog2.send({ embeds: [updateEmbed] });
})
client100.on('roleCreate' , async(role) => {
  if (!allDB.has(`log_rolecreate_${role.guild.id}`)) return;
  let roleCreateLog1 = allDB.get(`log_rolecreate_${role.guild.id}`);
      let roleCreateLog2 = role.guild.channels.cache.get(roleCreateLog1);
      const fetchedLogs = await role.guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.RoleCreate
      });
      const roleCreateLog = fetchedLogs.entries.first();
      const { executor } = roleCreateLog;
      let roleCreateEmbed = new EmbedBuilder()
        .setTitle('**تم انشاء رتبة**')
        .addFields(
          { name: 'اسم الرتبة :', value: `\`\`\`${role.name}\`\`\``, inline: true },
          { name: 'الذي قام بانشاء الرتبة :', value: `\`\`\`${executor.username} (${executor.id})\`\`\``, inline: true }
        )
        .setTimestamp();
      await roleCreateLog2.send({ embeds: [roleCreateEmbed] });
})
client100.on('roleDelete' , async(role) => {
  if (!allDB.has(`log_roledelete_${role.guild.id}`)) return;
  let roleDeleteLog1 = allDB.get(`log_roledelete_${role.guild.id}`);
      let roleDeleteLog2 = role.guild.channels.cache.get(roleDeleteLog1);
      const fetchedLogs = await role.guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.RoleDelete
      });

      const roleDeleteLog = fetchedLogs.entries.first();
      const { executor } = roleDeleteLog;

      let roleDeleteEmbed = new EmbedBuilder()
        .setTitle('**تم حذف رتبة**')
        .addFields({name:'اسم الرتبة :', value:`\`\`\`${role.name}\`\`\``, inline:true},{name:'الذي قام بحذف الرتبة :', value:`\`\`\`${executor.username} (${executor.id})\`\`\``, inline:true})
        .setTimestamp();

      await roleDeleteLog2.send({ embeds: [roleDeleteEmbed] });
})




client100.on('channelCreate', async (channel) => {
  if (allDB.has(`log_channelcreate_${channel.guild.id}`)) {
    let channelCreateLog1 = allDB.get(`log_channelcreate_${channel.guild.id}`);
    let channelCreateLog2 = channel.guild.channels.cache.get(channelCreateLog1);




    const fetchedLogs = await channel.guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.ChannelCreate
    });

    const channelCreateLog = fetchedLogs.entries.first();
    const { executor } = channelCreateLog;

    let channelCategory = channel.parent ? channel.parent.name : 'None';

    let channelCreateEmbed = new EmbedBuilder()
      .setTitle('**تم انشاء روم**')
      .addFields(
        { name: 'اسم الروم : ', value: `\`\`\`${channel.name}\`\`\``, inline: true },
        { name: 'كاتيجوري الروم : ', value: `\`\`\`${channelCategory}\`\`\``, inline: true },
        { name: 'الذي قام بانشاء الروم : ', value: `\`\`\`${executor.username} (${executor.id})\`\`\``, inline: true }
      )
      .setTimestamp();

    await channelCreateLog2.send({ embeds: [channelCreateEmbed] });
  }
});




client100.on('channelDelete', async (channel) => {
  if (allDB.has(`log_channeldelete_${channel.guild.id}`)) {
    let channelDeleteLog1 = allDB.get(`log_channeldelete_${channel.guild.id}`);
    let channelDeleteLog2 = channel.guild.channels.cache.get(channelDeleteLog1);




    const fetchedLogs = await channel.guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.ChannelDelete
    });

    const channelDeleteLog = fetchedLogs.entries.first();
    const { executor } = channelDeleteLog;

    let channelDeleteEmbed = new EmbedBuilder()
      .setTitle('**تم حذف روم**')
      .addFields(
        { name: 'اسم الروم : ', value: `\`\`\`${channel.name}\`\`\``, inline: true },
        { name: 'الذي قام بحذف الروم : ', value: `\`\`\`${executor.username} (${executor.id})\`\`\``, inline: true }
      )
      .setTimestamp();

    await channelDeleteLog2.send({ embeds: [channelDeleteEmbed] });
  }
});

client100.on('guildMemberUpdate', async (oldMember, newMember) => {
  const guild = oldMember.guild;
const addedRoles = newMember.roles.cache.filter((role) => !oldMember.roles.cache.has(role.id));
const removedRoles = oldMember.roles.cache.filter((role) => !newMember.roles.cache.has(role.id));




if (addedRoles.size > 0 && allDB.has(`log_rolegive_${guild.id}`)) {
    let roleGiveLog1 = allDB.get(`log_rolegive_${guild.id}`);
    let roleGiveLog2 = guild.channels.cache.get(roleGiveLog1);

    const fetchedLogs = await guild.fetchAuditLogs({
      limit: addedRoles.size,
      type: AuditLogEvent.MemberRoleUpdate
    });

    addedRoles.forEach((role) => {
      const roleGiveLog = fetchedLogs.entries.find((log) => log.target.id === newMember.id && log.changes[0].new[0].id === role.id);
      const roleGiver = roleGiveLog ? roleGiveLog.executor : null;
      const roleGiverUsername = roleGiver ? `${roleGiver.username} (${roleGiver.id})` : `UNKNOWN`;



      let roleGiveEmbed = new EmbedBuilder()
        .setTitle('**تم إعطاء رتبة لعضو**')
        .addFields(
          { name: 'اسم الرتبة:', value: `\`\`\`${role.name}\`\`\``, inline: true },
          { name: 'تم إعطاءها بواسطة:', value: `\`\`\`${roleGiverUsername}\`\`\``, inline: true },
          { name: 'تم إعطائها للعضو:', value: `\`\`\`${newMember.user.username} (${newMember.user.id})\`\`\``, inline: true }
        )
        .setTimestamp();

      roleGiveLog2.send({ embeds: [roleGiveEmbed] });
    });
  }

  if (removedRoles.size > 0 && allDB.has(`log_roleremove_${guild.id}`)) {
    let roleRemoveLog1 = allDB.get(`log_roleremove_${guild.id}`);
    let roleRemoveLog2 = guild.channels.cache.get(roleRemoveLog1);

    const fetchedLogs = await guild.fetchAuditLogs({
      limit: removedRoles.size,
      type: AuditLogEvent.MemberRoleUpdate
    });




    removedRoles.forEach((role) => {
      const roleRemoveLog = fetchedLogs.entries.find((log) => log.target.id === newMember.id && log.changes[0].new[0].id === role.id);
      const roleRemover = roleRemoveLog ? roleRemoveLog.executor : null;
      const roleRemoverUsername = roleRemover ? `${roleRemover.username} (${roleRemover.id})` : `UNKNOWN`;

      let roleRemoveEmbed = new EmbedBuilder()
        .setTitle('**تم إزالة رتبة من عضو**')
        .addFields(
          { name: 'اسم الرتبة:', value: `\`\`\`${role.name}\`\`\``, inline: true },
          { name: 'تم إزالتها بواسطة:', value: `\`\`\`${roleRemoverUsername}\`\`\``, inline: true },
          { name: 'تم إزالتها من العضو:', value: `\`\`\`${newMember.user.username} (${newMember.user.id})\`\`\``, inline: true }
        )
        .setTimestamp();


      roleRemoveLog2.send({ embeds: [roleRemoveEmbed] });
    });
  }
});
client100.on('guildMemberAdd', async (member) => {
  const guild = member.guild;
  if(!member.bot) return;
  const fetchedLogs = await guild.fetchAuditLogs({
    limit: 1,
    type: AuditLogEvent.BotAdd
  });




  const botAddLog = fetchedLogs.entries.first();
  const { executor, target } = botAddLog;

  if (target.bot) {
    let botAddLog1 = allDB.get(`log_botadd_${guild.id}`);
    let botAddLog2 = guild.channels.cache.get(botAddLog1);

    let botAddEmbed = new EmbedBuilder()
      .setTitle('**تم اضافة بوت جديد الى السيرفر**')
      .addFields(
        { name: 'اسم البوت :', value: `\`\`\`${member.user.username}\`\`\``, inline: true },
        { name: 'ايدي البوت :', value: `\`\`\`${member.user.id}\`\`\``, inline: true },
        { name: 'هل لدية صلاحية الادمن ستريتور ؟ :', value: member.permissions.has('ADMINISTRATOR') ? `\`\`\`نعم لديه\`\`\`` : `\`\`\`لا ليس لديه\`\`\``, inline: true },
        { name: 'تم اضافته بواسطة :', value: `\`\`\`${executor.username} (${executor.id})\`\`\``, inline: false }
      )
      .setTimestamp();

    botAddLog2.send({ embeds: [botAddEmbed] });
  }
});





client100.on('guildBanAdd', async (guild, user) => {
  if (allDB.has(`log_banadd_${guild.id}`)) {
    let banAddLog1 = allDB.get(`log_banadd_${guild.id}`);
    let banAddLog2 = guild.channels.cache.get(banAddLog1);

    const fetchedLogs = await guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.MemberBanAdd
    });

    const banAddLog = fetchedLogs.entries.first();
    const banner = banAddLog ? banAddLog.executor : null;
    const bannerUsername = banner ? `\`\`\`${banner.username} (${banner.id})\`\`\`` : `\`\`\`UNKNOWN\`\`\``;


    let banAddEmbed = new EmbedBuilder()
      .setTitle('**تم حظر عضو**')
      .addFields(
        { name: 'العضو المحظور:', value: `\`\`\`${user.tag} (${user.id})\`\`\`` },
        { name: 'تم حظره بواسطة:', value: bannerUsername },
      )
      .setTimestamp();

    banAddLog2.send({ embeds: [banAddEmbed] });
  }
});




client100.on('guildBanRemove', async (guild, user) => {
  if (allDB.has(`log_bandelete_${guild.id}`)) {
    let banRemoveLog1 = allDB.get(`log_bandelete_${guild.id}`);
    let banRemoveLog2 = guild.channels.cache.get(banRemoveLog1);

    const fetchedLogs = await guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.MemberBanRemove
    });

    const banRemoveLog = fetchedLogs.entries.first();
    const unbanner = banRemoveLog ? banRemoveLog.executor : null;
    const unbannerUsername = unbanner ? `\`\`\`${unbanner.username} (${unbanner.id})\`\`\`` : `\`\`\`UNKNOWN\`\`\``;

    let banRemoveEmbed = new EmbedBuilder()
      .setTitle('**تم إزالة حظر عضو**')
      .addFields(
        { name: 'العضو المفكّر الحظر عنه:', value: `\`\`\`${user.tag} (${user.id})\`\`\`` },
        { name: 'تم إزالة الحظر بواسطة:', value: unbannerUsername }
      )
      .setTimestamp();


    banRemoveLog2.send({ embeds: [banRemoveEmbed] });
  }
});


client100.on('guildMemberRemove', async (member) => {
  const guild = member.guild;
  if (allDB.has(`log_kickadd_${guild.id}`)) {
    const kickLogChannelId = allDB.get(`log_kickadd_${guild.id}`);
    const kickLogChannel = guild.channels.cache.get(kickLogChannelId);

    const fetchedLogs = await guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.MemberKick,
    });

    const kickLog = fetchedLogs.entries.first();
    const kicker = kickLog ? kickLog.executor : null;
    const kickerUsername = kicker ? `\`\`\`${kicker.username} (${kicker.id})\`\`\`` : 'Unknown';

    const kickEmbed = new EmbedBuilder()
      .setTitle('**تم طرد عضو**')
      .addFields(
        { name: 'العضو المطرود:', value: `\`\`\`${member.user.tag} (${member.user.id})\`\`\`` },
        { name: 'تم طرده بواسطة:', value: kickerUsername },
      )
      .setTimestamp();

    kickLogChannel.send({ embeds: [kickEmbed] });
  }
});
client100.on("ready" , async() => {
  let theguild = client100.guilds.cache.first();
  setInterval(() => {
      if(!theguild) return;
    let giveaways = allDB.get(`giveaways_${theguild.id}`)
    if(!giveaways) return;
    giveaways.forEach(async(giveaway) => {
      let {messageid , channelid , entries , winners , prize , duration,dir1,dir2,ended} = giveaway;
      if(duration > 0) {
        duration = duration - 1
        giveaway.duration = duration;
        await allDB.set(`giveaways_${theguild.id}` , giveaways)
      }else if(duration == 0) {
        duration = duration - 1
        giveaway.duration = duration;
        await allDB.set(`giveaways_${theguild.id}` , giveaways)
        const theroom = theguild.channels.cache.find(ch => ch.id == channelid)
        await theroom.messages.fetch(messageid)
        const themsg = await theroom.messages.cache.find(msg => msg.id == messageid)
        if(entries.length > 0 && entries.length >= winners) {
          const theWinners = [];
          for(let i = 0; i < winners; i++) {
            let winner = Math.floor(Math.random() * entries.length);
            let winnerExcept = entries.splice(winner, 1)[0];
            theWinners.push(winnerExcept);
          }
          const button = new ButtonBuilder()
.setEmoji(`🎉`)
.setStyle(ButtonStyle.Primary)
.setCustomId(`join_giveaway`)
.setDisabled(true)
const row = new ActionRowBuilder().addComponents(button)
          themsg.edit({components:[row]})
          themsg.reply({content:`Congratulations ${theWinners}! You won the **${prize}**!`})
          giveaway.ended = true;
          await allDB.set(`giveaways_${theguild.id}` , giveaways)
        }else{
          const button = new ButtonBuilder()
.setEmoji(`🎉`)
.setStyle(ButtonStyle.Primary)
.setCustomId(`join_giveaway`)
.setDisabled(true)
const row = new ActionRowBuilder().addComponents(button)
          themsg.edit({components:[row]})
          themsg.reply({content:`**لا يوجد عدد من المشتركين كافي**`})
          giveaway.ended = true;
          await allDB.set(`giveaways_${theguild.id}` , giveaways)
        }
      }
    })
  }, 1000);

})

client100.on("messageCreate" , async(message) => {
  if(message.author.bot) return;
const line = allDB.get(`line_${message.guild.id}`)
const chan = allDB.get(`feedback_room_${message.guild.id}`)
if(line && chan) {
    if(chan != message.channel.id) return;
  const embed = new EmbedBuilder()
  .setTimestamp()
  .setTitle(`**${message.content}**`)
  .setAuthor({name:message.author.username , iconURL:message.author.displayAvatarURL({dynamic:true})})
  await message.delete()
  const themsg = await message.channel.send({embeds:[embed]})
  await themsg.react("❤")
     await message.channel.send({content:`${line}`})

}
})

client100.on("messageCreate" , async(message) => {
  if(message.author.bot) return;
  if(message.content.startsWith(`${prefix}credit`) || message.content.startsWith(`${prefix}credits`) || message.content.startsWith(`c`)) {
    let userCredits = allDB.get(`credits_${message.author.id}_${message.guild.id}`)
    if(!userCredits) {
        await allDB.set(`credits_${message.author.id}_${message.guild.id}` , 0)
    }
    userCredits = allDB.get(`credits_${message.author.id}_${message.guild.id}`)
    let userId = message.content.split(" ")[1]
    if(!userId) {
      return message.reply({content:`**:bank: |  ${message.author.username}, your account balance is \`$${userCredits}\`.**`})
    }
    let user = message.mentions.members.first() ?? await client100.users.fetch(userId)
    let amount = message.content.split(" ")[2]
    if(!amount) {
      let user2Credits = allDB.get(`credits_${user.id ?? user.user.id}_${message.guild.id}`)
    if(!user2Credits) {
        await allDB.set(`credits_${user.id ?? user.user.id}_${message.guild.id}` , 0)
    }
    user2Credits = allDB.get(`credits_${user.id ?? user.user.id}_${message.guild.id}`)
      return message.reply({content:`**${user.username ?? user.user.username} :credit_card: balance is \`$${user2Credits}\`.**`})
    }
    let user2Credits = allDB.get(`credits_${user.id ?? user.user.id}_${message.guild.id}`)
    if(!user2Credits) {
        await allDB.set(`credits_${user.id ?? user.user.id}_${message.guild.id}` , 0)
    }
    user2Credits = allDB.get(`credits_${user.id ?? user.user.id}_${message.guild.id}`)
    if(amount > userCredits) return message.reply({content:`**:thinking: | r9_9, Your balance is not enough for that!**`})
    const theTax = Math.floor(parseInt(amount) * (5 / 100))
    const theFinal = parseInt(amount) - parseInt(theTax)
    const theFinalNum = theFinal
    const randomCaptcha = getCaptcha();
    let {captcha , number} = randomCaptcha;
    let messageReply = await message.reply({content:`** ${message.author.username}, Transfer Fees: \`${theTax}\`, Amount :\`$${theFinalNum}\`**\ntype these numbers to confirm :` , files:[{name:`captcha.png` , attachment:`${captcha}`}]})
   setTimeout(() => {
    try {
      messageReply.delete().catch(async() => {return;});
    } catch  {
      return;
    }
   }, 15 * 1000);
    const filter = ((m => m.author.id == message.author.id))
    const messageCollect = message.channel.createMessageCollector({
      filter:filter,
      time:15 * 1000,
      max:1
    })
    messageCollect.on("collect" , async(msg) => {
      try {
      if(msg.content == number) {
        let newUser1 = parseInt(userCredits) - parseInt(amount)
        let newUser2 = parseInt(userCredits) + parseInt(theFinalNum)
        await allDB.set(`credits_${user.id ?? user.user.id}_${message.guild.id}` , newUser2)
        await allDB.set(`credits_${message.author.id}_${message.guild.id}` , newUser1)
        await msg.reply({content:`**:moneybag: | ${message.author.username}, has transferred \`$${theFinalNum}\` to ${user}**`})
        await messageReply.delete();
        return msg.delete();  
      }else {
        await messageReply.delete().catch(async() => {return;});
       return msg.delete().catch(async() => {return;});
      }
    } catch {
        return;
      }
    })
  }
  })

  
  client100.on('guildMemberAdd' , async(member) => {
    const dataFind = allDB.get(`blacklisted_${member.guild.id}`)
    if(dataFind) {
      if(!dataFind.includes(member.user.id)) return;
      const roleFind = allDB.get(`blacklist_role_${member.guild.id}`)
      if(roleFind) {
        try {
          member.roles.add(roleFind)
        } catch {
          return;
        }
      }
    }
  })
  client100.on("guildMemberAdd" , async(member) => {
    const guild = member.guild;
    let dataFind = allDB.get(`blacklisted_${guild.id}`)
    if(!dataFind) {
      await allDB.set(`blacklisted_${guild.id}` , [])
    }
    dataFind = allDB.get(`blacklisted_${guild.id}`)
    const roleFind = allDB.get(`blacklist_role_${guild.id}`)
    if(!roleFind) {
      return;
    }
    if(dataFind.includes(member.user.id)) {
      await member.roles.add(roleFind)
    }
  } )

  client100.on('guildMemberUpdate', async (oldMember, newMember) => {
    const guild = oldMember.guild;
    const removedRoles = oldMember.roles.cache.filter((role) => !newMember.roles.cache.has(role.id));
    if (removedRoles.size > 0 && allDB.get(`blacklist_role_${guild.id}`)) {
      let roleRemoveLog1 = allDB.get(`blacklist_role_${guild.id}`)
      
      removedRoles.forEach(async(role) => {
        let dataFind = allDB.get(`blacklisted_${guild.id}`)
        if(!dataFind) {
          await allDB.set(`blacklisted_${guild.id}` , [])
        }
        dataFind = allDB.get(`blacklisted_${guild.id}`)
        const roleFind = allDB.get(`blacklist_role_${guild.id}`)
        if(!roleFind) {
          return;
        }
        if(dataFind.includes(newMember.user.id)) {
          await newMember.roles.add(roleFind)
        }
      });
    }
  });

  client100.on("messageCreate" , async(message) => {
    if(message.author.bot) return;
    try {
      if(message.content == "-" || message.content == "خط") {
        const line = allDB.get(`line_${message.guild.id}`)
        if(line) {
          await message.delete()
          return message.channel.send({content:`${line}`});
        }
      }
    } catch (error) {
      return;
    }
   
  })
  
  client100.on("messageCreate" , async(message) => {
    if(message.author.bot) return;
    const autoChannels = allDB.get(`line_channels_${message.guild.id}`)
      if(autoChannels) {
        if(autoChannels.length > 0) {
          if(autoChannels.includes(message.channel.id)) {
            const line = allDB.get(`line_${message.guild.id}`)
        if(line) {
          return message.channel.send({content:`${line}`});
          }
        }
        }
      }
  })
  


  client100.on('ready' , async() => {
    setInterval(async() => {
      let BroadcastTokenss = tokens.get(`all`)
      let thiss = BroadcastTokenss.find(br => br.token == token)
      if(thiss) {
        if(thiss.timeleft <= 0) {
          await client100.destroy();
          console.log(`${clientId} Ended`)
        }
      }
    }, 1000);
  })
  
  
    client100.on("interactionCreate" , async(interaction) => {
      if (interaction.isChatInputCommand()) {
        
          if(interaction.user.bot) return;
  
        
        const command = client100.allSlashCommands.get(interaction.commandName);
          
        if (!command) {
          console.error(`No command matching ${interaction.commandName} was found.`);
          return;
        }
        if (command.ownersOnly === true) {
          if (owner != interaction.user.id) {
            return interaction.reply({content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true});
          }
        }
        try {
  
          await command.execute(interaction);
        } catch (error) {
              return
          }
      }
    } )
  
  
  })
})
     client100.login(token)
})
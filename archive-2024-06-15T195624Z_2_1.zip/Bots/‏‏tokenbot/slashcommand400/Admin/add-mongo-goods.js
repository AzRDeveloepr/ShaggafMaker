const { SlashCommandBuilder, EmbedBuilder , TextInputBuilder ,TextInputStyle,ActionRowBuilder ,ModalBuilder ,PermissionsBitField } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/tokenbotDB.json")
module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('add-tokenbot-goods')
    .setDescription('اضافة كميو توكنات بوت معين'), 
async execute(interaction) {
    let products = db.get(`products_${interaction.guild.id}`)
    if(!products) return interaction.reply({content:`**لا يوجد مونجو لأضافة سلع اليها**`})
    if(products.length <= 0) return interaction.reply({content:`**لا يوجد منجو لأضافة سلع اليها**`})
    const modal = new ModalBuilder()
    .setCustomId(`add_goods`)
    .setTitle(`Add tokenbot Goods`)
    const type = new TextInputBuilder()
    .setCustomId(`type`)
    .setLabel(`tokenbot Name`)
    .setStyle(TextInputStyle.Short)
    const code = new TextInputBuilder()
    .setCustomId(`Goods`)
    .setLabel(`Goods`)
    .setStyle(TextInputStyle.Paragraph)
    const row = new ActionRowBuilder().addComponents(type)
    const row2 = new ActionRowBuilder().addComponents(code)
    modal.addComponents(row,row2)
    await interaction.showModal(modal)
}
}
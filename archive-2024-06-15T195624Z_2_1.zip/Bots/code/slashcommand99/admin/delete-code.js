const { SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/codeDB.json")

module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('remove-code')
    .setDescription('ازالة كود')
  .addStringOption(text => text
    .setName(`code-name`)
    .setDescription(`اسم كود`)
    .setRequired(true)),
  
  
  async execute(interaction) {


    const codeName = interaction.options.getString('code-name');

    const codes = await db.get(`codes_${interaction.guild.id}`);

    const codeToRemove = codes.find(product => product.productName === codeName);

    if (!codeToRemove) return interaction.reply({ content: `**كود غير موجود.**`, ephemeral: true });

    db.set(`codes_${interaction.guild.id}`, codes.filter(code => code.codeName !== codeName));

    interaction.reply({ content: `**تم إزالة كود بنجاح**` });
    
  }
}
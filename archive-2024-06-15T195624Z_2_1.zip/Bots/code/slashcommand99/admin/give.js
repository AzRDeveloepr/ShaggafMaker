const { SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/codeDB.json")

module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('give')
    .setDescription('اعطاء كود')
  .addUserOption(Option => Option
    .setName(`user`)
    .setDescription(`الشخص`)
    .setRequired(true))
.addStringOption(text => text
    .setName(`code-name`)
    .setDescription(`اسم كود`)
    .setRequired(true))
,
  
  async execute(interaction) {
    const recipient = interaction.options.getUser('user');
    const selectedcode = interaction.options.getString('code-name');
    
    const codes = await db.get(`codes_${interaction.guild.id}`);
    const codeData = codes.find(code => code.codeName === selectedcode);

    if (!codeData) {
      return interaction.reply({ content: '**لا يمكن العثور على اسم البروجكت المحدد.**', ephemeral: true });
    }

    const codeLink = codeData.codeLink;

    await recipient.send(`**تم منحك رابط للبروجكت: ${codeLink}**`);
    await interaction.reply({ content: `**✅ تم إرسال الرابط بنجاح لـ ${recipient}**` });
  }
};

async function getProjectChoices() {
  const codes = await db.get(`codes_${interaction.guild.id}`) || [];
  const choices = [];

  for (const code of codes) {
    choices.push({
      name: code.productName,
      value: code.productName
    });
  }

  return choices;
}

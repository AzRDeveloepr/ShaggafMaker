const { SlashCommandBuilder, EmbedBuilder,TextInputBuilder,ModalBuilder , PermissionsBitField,TextInputStyle, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/Json-db/Bots/sellerDB.json")

module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('edit')
    .setDescription('تعديل كود'),
  
  async execute(interaction) {
    const modal = new ModalBuilder()
		  .setCustomId('updatecode')
		  .setTitle('تعديل اكواد');

    const oldcodeName = new TextInputBuilder()
		  .setCustomId('oldName') .setLabel('قم بإدخال الإسم القديم للكود') .setRequired(true) .setStyle(TextInputStyle.Short);

	  const newcodeName = new TextInputBuilder()
		  .setCustomId('newName') .setLabel('قم بإدخال الإسم الجديد للكود') .setRequired(true) .setStyle(TextInputStyle.Short);

    const newcodePrice = new TextInputBuilder()
		  .setCustomId('newPrice') .setLabel('قم بإدخال السعر الجديد للبروجكت') .setRequired(true) .setStyle(TextInputStyle.Short);

    const newcodeLink = new TextInputBuilder()
		  .setCustomId('newLink') .setLabel('قم بإدخال الرابط الجديد للبروجكت') .setRequired(true) .setStyle(TextInputStyle.Short);

    const oldName = new ActionRowBuilder().addComponents(oldcodeName);
    const newName = new ActionRowBuilder().addComponents(newcodeName);
    const newPrice = new ActionRowBuilder().addComponents(newcodePrice);
    const newLink = new ActionRowBuilder().addComponents(newcodeLink);

	  modal.addComponents(oldName, newName, newPrice, newLink);
	  await interaction.showModal(modal);
    
  }
}